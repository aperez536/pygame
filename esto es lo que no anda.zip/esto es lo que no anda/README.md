﻿VIERNES 18/08 ----22:00HS

Tema del juego: aliens/espacio/extraterrestre
a definir:
1) aliens que huyen de tiros de naves || 
2) aliens que huyen de meteoritos ||                  
3) Buscar todas las piezas de la nave y arreglarla


El juego consta de 2 niveles. Uno inicial a definir [ 1), 2) o 3) ] y un segundo nivel, donde entra en un planeta diferente que puede ser su hogar
[Inclui el archivo .py para luego comenzar con la programación.]

ºPuede ser que el primer nivel el alien busque las piezas de la nave para repararla y el segundo nivel, vuelve a su hogar esquivando meteoros o balas de otras naves.

ºMICAELA

**********************************************************

pruebo si anda
by:Nicolás
**********************************************************

DOMINGO 20/08 ------ 9:06HS

Empece la programacion del juego, solo incluyendo cosas basicas tales como el tamaño del display, algunos colores basicos y el cierre del juego.
ºMICAELA
-
-22:08HS
Agregado de una carpeta con contenido de imagenes que tendrá el juego(con una dentro .PNG que podria ser el personaje)

ºMICAELA
 
***********************************************************

Jueves 24/08 ----- 17:44HS

agregado en la carpeta de imagenes " un alien con sus respectivos movimientos(.png),tuerca y tornillo.
by: Alan
**********************************************************

Jueves 31/08 ----- 20:36HS

Editando el codigo del juego. Agregado una imagen temporal a modo de personaje, movimientos básicos del mismo, funciones,colisiones con los bordes y un mensaje de aviso cuando esto ocurre.

ºMICAELA

***********************************************************

Domingo 3/09 ------- 10:39HS
Agregue una extension al repository del bitbucket que es un administrador de tareas, cumple la funcion del KANBAN y se llama "Bucketboard". Ademas agregue una carpeta "Documentacion" y dentro otra mas, donde se encuentras los screenshots del Bucketboard, como se pide en el TP.
ºMICAELA

*********************************************************

Domingo 03/09 ----- 15:20HS

Editando el codigo del juego. Mejorado el movimiento del personaje.

By:Alan

************************************************

DOMINGO 3/09 --------------- 19:51

Arreglado de constantes. Inclui dentro de la carpeta documentacion, un archivo donde esta la prueba del menu del juego.

ºMICAELA
***********************************************

Jueves 7/09------------- 15:19

editado el codigo del juego. agregado movimiento visual del personaje.

by:alan

******************************
Viernes 08/09------------ 17:25

editado el codigo del juego. agrege las piezas que tiene que buscar el alien, agarrar las piezas, y cuando llegue a la nave con esas piezas , se mostrara el mensaje que gano el juego. 

by:alan
***************************
SABADO 9/9 -------------19:48HS
Agregue Imagen de Fondo
Nueva carpeta de Clases
Nuevas Clases Config(se encarga de la configuración básica) y Alien (Se encarga del Personaje)
Nuevo archivo Constantes.py que se encarga de todas las CONSTANTES que tiene el juego y Configuraciones Estáticas
Nueva función que actualiza los FPS desde Config
Y un par de arreglos varios que no me acuerdo pero eran espacios y cosas mal puestas
ºMICAELA
************************************
DOMINGO 10/9 -------------22:07HS
Resumen del Dia:
Agregada una clase de Mensajes.py que se encarga de mostrar mensajes en la pantalla para posibles puntuaciones, vida o nombre del alien (Interfaz de la pantalla)
Eliminado archivos de Debug
Agregado un archivo gitIgnore para los archivos de debug
Arreglos varios de sintaxis
Arreglo de bug - las imagenes titilaban flikering por repeticion del display.update()
ºMICAELA
************************************
MARTES 12/09 ------------- 20:36HS
Cambios y actualizaciones simples, fonts, arreglado de espacios y volviendo a mejorar el menú. Agregado el Menu a la carpeta de "Clases".
ºMICAELA
**************************************
MIERCOLES 13/09---------- 19:40HS
El menu esta casi terminado.Inlcuidas musica, inicio del juego y salida. Queda solucionar pequeños bugs y agregar una ultima opcion de instrucciones.
ºMICAELA
***************************************************